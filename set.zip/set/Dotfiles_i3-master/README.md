Configuration files for i3wm with Arc-Themed i3 & terminal 2017-05-08
To be placed in ~/.config:
conky
i3
i3status
 
To be placed in ~/.local/share or ~/.fonts
fonts
 
To be placed in /usr/bin
i3exit
i3lock
 
To be placed in ~/
.bashrc
.Xresources
 
Optional:
Configuration file for ranger
rc.conf ~/.config/ranger
Configuration file for dunst
dunstrc ~/.config
 
Packages used in configuration: nm-applet pa-applet nitrogen neofetch compton xautolock i3gaps i3status i3lock powerline lxappearance rofi morc_menu dunst dmenu rxvt-unicode scrot
 
Themes and Icons:
Arc-Theme https://github.com/horst3180/arc-theme
Icons https://github.com/horst3180/arc-icon-theme

To get powerline to work: https://wiki.archlinux.org/index.php/Powerline

