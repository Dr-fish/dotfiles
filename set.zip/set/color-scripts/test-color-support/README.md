# Color Support

These are some scripts to display the current number of colors supported by your Term.
