/* See LICENSE file for copyright and license details. */
void parseimg(char *, void (*)(int, int, int));
